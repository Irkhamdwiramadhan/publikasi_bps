<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('submission_comments', function (\Illuminate\Database\Schema\Blueprint $table) {
            $table->string('role')->default('Penyusun')->change();
        });
    }

    public function down(): void
    {
        Schema::table('submission_comments', function (\Illuminate\Database\Schema\Blueprint $table) {
            $table->string('role')->nullable()->change();
        });
    }
};
